# Frigg Café Regular

**Version 1.000**

Frigg Café is a display serif for cafés, restaurants, bars and lifestyle brands. Its signature is a **wave**: when a capital letter is repeated (PIZZA, COFFEE, JAZZ, MOZZARELLA…), the second letter automatically takes a flowing, calligraphic form.

- **Designer:** Arnaud Wilbrod
- **Foundry:** Frigg Digital (Frigg Digital OÜ)
- **Website:** https://friggcafe.com
- **License:** SIL Open Font License 1.1 — see `OFL.txt`. Reserved Font Name: “Frigg Café”.

## Files

| File | Use |
|---|---|
| `FriggCafe-Regular.otf` | Desktop (OpenType, PostScript outlines) |
| `FriggCafe-Regular.ttf` | Desktop and apps (OpenType, TrueType outlines) |
| `FriggCafe-Regular.woff2` | Websites |

All three files come from the same source and render the same text identically. Install either the OTF or the TTF on a computer, not both.

Also included: `OFL.txt` (license), `FONTLOG.txt` (history), `OPENTYPE_FEATURES.md` (how the wave works), `SPECIMEN.pdf` and `SHA256SUMS.txt` (checksums of all files).

## Installation

- **macOS:** double-click `FriggCafe-Regular.otf` and click “Install”, or drag it into Font Book.
- **Windows:** right-click `FriggCafe-Regular.otf` (or `.ttf`) and choose “Install” (or “Install for all users”).
- **Linux:** copy the file to `~/.local/share/fonts/` and run `fc-cache -f`.
- **Websites:** host `FriggCafe-Regular.woff2` with your site and declare it with `@font-face` (see below).

If an earlier version of Frigg Café is installed, remove it first.

## Character set

489 characters, 747 glyphs: Latin (basic, Latin-1, Latin Extended-A, plus additional Latin letters) and Cyrillic (including Bulgarian, Macedonian and Serbian forms), figures (proportional and tabular), punctuation, currency and common symbols. According to Hyperglot 0.8.1, the font covers the base and auxiliary characters of 281 living languages written in Latin or Cyrillic.

## The wave (contextual alternates, `calt`)

The wave is an OpenType feature: **Contextual Alternates** (`calt`). There is nothing to type. Write the word normally, and in applications that apply `calt` the second of two identical capitals gets its wave.

- The wave works on doubled capitals in Latin, extended Latin (À Ä Ñ Ž…) and Cyrillic (ЖЖ, ЛЛ, ДД…).
- When a wave would touch a neighbouring letter (for example ZZ before A in PIZZA, or AA before J), the font automatically picks an adapted form of the same wave: slightly lowered, or shorter. The movement stays the same.
- In a run of identical capitals, waves alternate (XXXX → X X~ X X~).
- Combining accents typed separately (for example a Cyrillic stress mark, И + U+0301) do not interrupt this choice: in almost all cases the font picks the same adapted form, the same exception and the same kerning as for the letter without the accent (see Known limitations).

**Application support.** `calt` is applied by default in most applications with modern OpenType support, including web browsers and current professional design software. Some applications apply it only when “Contextual Alternates” is switched on, and some do not support it at all. Without `calt`, the text stays fully legible and correctly spaced, but shows no waves. Check your application before using the font for a final layout.

**On the web:** `calt` is on by default. To turn the waves off, use `font-variant-ligatures: no-contextual;` (or `font-feature-settings: "calt" 0;`).

```css
@font-face {
  font-family: "Frigg Café";
  src: url("FriggCafe-Regular.woff2") format("woff2");
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}
```

Other features: `kern` (kerning), `mark` / `mkmk` (accent positioning, including combining accents), `ccmp`, `locl` (Bulgarian, Macedonian and Serbian Cyrillic forms; set the text language to get them), `tnum` (tabular figures).

## Known limitations

- A small number of very rare sequences keep no wave because no adapted form is clean enough: ĄĄ + J/Ĵ/_, ĘĘ + Ĵ, RR/ŔŔ/ŘŘ + ‡, ДД + _, RR + a narrow sign + a descender (for example RR1J), and G/Ĝ/Ğ/Ġ doubled + combining comma below (U+0326). None of them occurs in the supported languages.
- After a doubled capital, some lowercase letters or letters from the other script (for example AAg, latin ZZ + cyrillic Д) do not trigger a wave.
- Combining accents without a precomposed form (a letter followed by a separate combining mark that Unicode has no single character for): in rare combinations, mostly a combining comma below or ogonek under the second letter of a doubled capital (for example Z + U+0326, a sequence no supported language uses; Zapotec Z̨ is the only attested case), the wave can still come close to or touch the next sign or its own accent. Precomposed letters (Ą, Ș, Ģ…) and their decomposed (NFD) forms are not affected.
- Mixed scripts: some applications (web browsers) shape Latin and Cyrillic runs separately, so a wave or kerning that depends on a letter of the other script may not apply.
- See `OPENTYPE_FEATURES.md` for the full description.

## License

Frigg Café is free software under the SIL Open Font License 1.1. You can use it for personal and commercial work, embed it, and redistribute it, including bundled with software. You may not sell the font file on its own. Modified versions must not use the Reserved Font Name “Frigg Café”. The full text is in `OFL.txt`; the official text and the FAQ are at https://openfontlicense.org/open-font-license-official-text/ and https://openfontlicense.org/ofl-faq/.

Copyright 2026 Frigg Digital OÜ (https://friggcafe.com), with Reserved Font Name "Frigg Café".
