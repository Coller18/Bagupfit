# Frigg Café — OpenType features

Version 1.000. This document describes the OpenType layout of Frigg Café Regular, mainly the contextual wave (`calt`).

## Feature list

| Feature | Purpose |
|---|---|
| `calt` | Contextual alternates: the wave on doubled capitals (default on) |
| `kern` | Kerning (class and pair kerning, including all wave forms; pair kerning skips combining marks) |
| `mark`, `mkmk` | Accent positioning, including combining marks on wave forms |
| `ccmp` | i / j / і / ј lose their dot under a top accent |
| `locl` | Bulgarian (BGR), Macedonian (MKD) and Serbian (SRB) Cyrillic forms |
| `tnum` | Tabular figures |

Scripts: `DFLT`, `latn`, `cyrl`. NFC and NFD input give the same result: decomposed accented letters are recomposed when a precomposed glyph exists.

## The wave

When a capital letter is followed by the same capital, the second one is replaced by its wave form. The rule is applied left to right, so in a run of identical capitals waves alternate: `XX → X X~`, `XXXX → X X~ X X~`.

Doubled capitals with a wave (145):

- Latin and extended Latin (109): ABCDEFGHIJKLMNOPQRSTUVWXYZÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝĀĂĄĆĈĊČĎĒĔĖĘĚĜĞĠĤĨĪĬĮİĴĹĻŃŇŌŎŐŔŘŚŜŞŠŢŤŨŪŬŮŰŲŴŶŸŹŻŽǍȘȚẀẂẄỲ
- Cyrillic (36): ЀЁЂЄЅІЈЋАБВГДЕЖИЙКЛМНОПРСТФХЧЪЫЬЭЮЯҐ

Ģ, Ķ, Ļ… with cedilla follow the same rule when they have a wave form (ĻĻ has one; ĢĢ and ĶĶ do not).

## Contextual wave forms

In text without separate combining marks, every doubled-capital context of the font (145 doubled capitals × 475 following signs) keeps at least 10 units (1 % of the em) of clearance between the wave and the nearby glyphs; the few contexts where no clean form exists keep no wave (see Exceptions). When the original wave would come closer, `calt` picks an adapted form of the **same** wave instead of removing it.

| Glyph name pattern | Form | Number |
|---|---|---|
| `X.alt` | original wave | 129 |
| `Z.alt.A`, `Zacute.alt.A`, `Zcaron.alt.A`, `Zdotaccent.alt.A` | wave start lowered by 16 units (ZZ before A and its accented forms, Ź Ż Ž, Ķ, Ţ, 1, 2: PIZZA, MOZZARELLA) | 4 |
| `X.alt.r1` | shortened wave, level 1: same movement and weight, shorter path (before J Ĵ Ј, Į Ĳ, cedilla and comma-below capitals, comma, semicolon, accented I, Ĺ…) | 78 |
| `X.alt.r2` | shortened wave, level 2, only where level 1 is not enough (Д, parentheses, brackets, slash, ¿…) | 11 |
| `L.alt.r1`, `Lacute.alt.r1`, `F.alt.r1` | shortened left wave of LL / ĹĹ / FF after another wave (KEVÄÄLLÄ) | (included above) |
| `uni0414.alt.court`, `I.alt.low`, `Iogonek.alt.low`, `uni0424.alt.low` | earlier contextual forms (ДДД; I and Ф under a combining top accent) | 4 |

Every wave form has exactly the advance width and kerning of its original wave, so choosing a form never changes the spacing of a word.

## Order of the rules

The first rule that matches wins:

1. ДД before Д / д → `uni0414.alt.court`.
2. Wave that reaches past two narrow signs (thin spaces, apostrophes, punctuation) and would touch the next glyph → adapted form.
3. Wave that reaches past one narrow sign (space, apostrophe, period, colon, I, i, 1…) → adapted form (for example JAZZ JAM).
4. Wave against wave (ÄÄLL): the first wave stays original, the left wave of LL / ĹĹ / FF takes its shortened form.
5. Wave touching the next glyph → the closest adapted form that clears it.
6. Documented exceptions: no wave (see below).
7. Earlier rules: I / Ф before a combining top accent → `.low` forms; waves removed before combining marks below that they would touch.
8. Base rule: `X X' → X.alt`.

Rules 2 to 6 also exist with one or two combining marks between the doubled capital and the next sign (for example И + stress mark U+0301 + next letter), so the same adapted form or exception is chosen as without the mark. A copy is not used when the adapted form would touch the mark itself, or when a dedicated mark rule (7) exists for that letter and mark; the font then behaves as in the original rule set.

## Exceptions (no wave)

These contexts keep the plain letter because no adapted form is clean:

- ĄĄ + J, Ĵ, _ ; ĘĘ + Ĵ ; RR, ŔŔ, ŘŘ + ‡ ; ДД + _ ;
- RR + a narrow sign (1, i, l, ı, ľ, ŀ, ł, r, ŕ, ř, г, ѓ, ґ) + a descender (J, /, g, Д…);
- GG, ĜĜ, ĞĞ, ĠĠ + combining comma below (U+0326);
- after a doubled capital: some lowercase letters, or letters of the other script (AAg, NNј, latin RR + cyrillic Д…) — outside the doubled-capital use of the font.

## Disabling the waves

- CSS: `font-variant-ligatures: no-contextual;` or `font-feature-settings: "calt" 0;`
- Desktop applications: turn off “Contextual Alternates” in the OpenType options.

Without `calt` no wave form is ever displayed.

## Known limitations with combining marks

For a letter followed by a separate combining mark that has no precomposed form, a small number of combinations can still bring the wave into contact with the next sign or with its own accent: mostly a combining comma below or ogonek under a doubled capital (sequences not used by the supported languages; Zapotec Z̨ is the only attested case), and a few two-mark stacks (a mark below — comma below, cedilla or ogonek — followed by a top accent, on I, Į, І or Ф). Precomposed letters and their NFD forms are not affected.
